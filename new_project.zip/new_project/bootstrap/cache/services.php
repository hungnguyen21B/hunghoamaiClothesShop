<?php return array (
  'providers' => 
  array (
    0 => 'BeyondCode\\DumpServer\\DumpServerServiceProvider',
    1 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    2 => 'Laravel\\Tinker\\TinkerServiceProvider',
    3 => 'Collective\\Html\\HtmlServiceProvider',
    4 => 'Carbon\\Laravel\\ServiceProvider',
    5 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    6 => 'Bootstrapper\\BootstrapperL5ServiceProvider',
    7 => 'Bootstrapper\\BootstrapperL5ServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'BeyondCode\\DumpServer\\DumpServerServiceProvider',
    1 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    2 => 'Carbon\\Laravel\\ServiceProvider',
    3 => 'Bootstrapper\\BootstrapperL5ServiceProvider',
    4 => 'Bootstrapper\\BootstrapperL5ServiceProvider',
  ),
  'deferred' => 
  array (
    'command.tinker' => 'Laravel\\Tinker\\TinkerServiceProvider',
    'html' => 'Collective\\Html\\HtmlServiceProvider',
    'form' => 'Collective\\Html\\HtmlServiceProvider',
    'Collective\\Html\\HtmlBuilder' => 'Collective\\Html\\HtmlServiceProvider',
    'Collective\\Html\\FormBuilder' => 'Collective\\Html\\HtmlServiceProvider',
    'NunoMaduro\\Collision\\Contracts\\Provider' => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
  ),
  'when' => 
  array (
    'Laravel\\Tinker\\TinkerServiceProvider' => 
    array (
    ),
    'Collective\\Html\\HtmlServiceProvider' => 
    array (
    ),
    'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider' => 
    array (
    ),
  ),
);